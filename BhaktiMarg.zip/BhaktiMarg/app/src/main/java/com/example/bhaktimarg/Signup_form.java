package com.example.bhaktimarg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Signup_form extends AppCompatActivity {

    EditText txtFullName, txtMobile, txtEmail, txtPassword, txtConfirmPassword;
    Button btnRegister;
    RadioButton radioGenderMale,radioGenderFemale;
    DatabaseReference databaseReference;
    String gender="";
    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_form);
        getSupportActionBar().hide();


        txtFullName = (EditText) findViewById(R.id.txtFullName) ;
        txtMobile = (EditText) findViewById(R.id.txtMobile) ;
        txtEmail = (EditText) findViewById(R.id.txtEmail) ;
        txtPassword = (EditText) findViewById(R.id.txtPassword) ;
        txtConfirmPassword = (EditText) findViewById(R.id.txtConfirmPassword) ;
        btnRegister = (Button) findViewById(R.id.btnRegister) ;
        radioGenderMale = (RadioButton) findViewById(R.id.radiomale);
        radioGenderFemale = (RadioButton) findViewById(R.id.radiofemale);

        databaseReference = FirebaseDatabase.getInstance() .getReference("Users");




        firebaseAuth = FirebaseAuth.getInstance();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String email = txtEmail.getText() .toString() .trim();
                String password = txtPassword.getText() .toString() . trim();
                String confirmPassword = txtConfirmPassword.getText() .toString() .trim();
                final String mobile = txtMobile.getText() .toString() .trim();
                final String fullname =txtFullName.getText() .toString() .trim();

                if(radioGenderMale.isChecked()) {
                    gender="Male";
                }

                if(radioGenderFemale.isChecked()) {
                    gender="Female";
                }

                if (TextUtils.isEmpty(fullname)) {
                    Toast.makeText(Signup_form.this, "Please Enter Full Name", Toast.LENGTH_SHORT) .show();
                    return;
                }

                if (TextUtils.isEmpty(mobile)) {
                    Toast.makeText(Signup_form.this, "Please Enter Mobile Number", Toast.LENGTH_SHORT) .show();
                    return;
                }


                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(Signup_form.this, "Please Enter Email", Toast.LENGTH_SHORT) .show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(Signup_form.this, "Please Enter Password", Toast.LENGTH_SHORT) .show();
                    return;
                }
                if (TextUtils.isEmpty(confirmPassword)) {
                    Toast.makeText(Signup_form.this, "Please Enter ConfirmPassword", Toast.LENGTH_SHORT) .show();
                    return;
                }
                if (password.length()<6) {

                    Toast .makeText(Signup_form.this, "Password too short", Toast.LENGTH_SHORT) .show();
                }
                if (password.equals(confirmPassword)) {

                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(Signup_form.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        Users information = new Users(
                                                fullname,
                                                mobile,
                                                email,
                                                gender

                                        );

                                        FirebaseDatabase.getInstance() .getReference("Users")
                                                .child(FirebaseAuth.getInstance() .getCurrentUser() .getUid())
                                                .setValue(information) .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                                FirebaseAuth.getInstance().getCurrentUser().sendEmailVerification() .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    private static final String TAG = "emailSent" ;

                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            Log.d(TAG, "Email sent.");
                                                        }
                                                    }
                                                });

                                                Toast.makeText(Signup_form.this, "Registered Successfully", Toast.LENGTH_SHORT).show();





                                                startActivity(new Intent(getApplicationContext() ,Login_form.class));
                                            }
                                        });


                                    } else {

                                        Toast.makeText(Signup_form.this, "Authentication Failed", Toast.LENGTH_SHORT).show();

                                    }
                                    // ...
                                }
                            });

                }
            }
        });

    }


}