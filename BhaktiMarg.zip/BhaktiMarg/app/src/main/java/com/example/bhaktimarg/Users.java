package com.example.bhaktimarg;

public class Users {
    public String FullName,Mobile,Email,Gender;
    public Users(){

    }

    public Users(String fullName, String mobile, String email, String gender) {
        FullName = fullName;
        Mobile = mobile;
        Email = email;
        Gender = gender;
    }
}
